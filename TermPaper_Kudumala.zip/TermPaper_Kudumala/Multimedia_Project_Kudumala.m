%Developed by Nava Yodhan Reddy Kudumala.
%Last Modified 4/26/2017.
%Image with 2 clusters.
tic;
he = imread('image_1.png');

%Image with 3 clusters.
%he = imread('image_2.png');

%Another image with 3 clusters.
%he = imread('image_3.jpg');

% To convert to lab format.
cform = makecform('srgb2lab');
lab_he = applycform(he,cform);

% Take only a and b values and store to ab.
ab = double(lab_he(:,:,2:3));
nrows = size(ab,1);
ncols = size(ab,2);
% Reshaping them into 2 columns.
ab1 = reshape(ab,nrows*ncols,2);

%calculating threshold value l
dis1 = 0.0;
dis2 = 0.0;
dis3 = 0.0;
dis4 = 0.0;
c1 = 0;
c2 = 0;
c3 = 0;
c4 = 0;
z = 1;
%Four clusters are taken initially to identify threshold value
%kmeans function does kmeans clustering in Matlab
[km1, c] = kmeans(ab1,4);
nrows1 = size(ab1,1);
%Similarity for each cluster is identified by calculating the distance to
%center.
for kk =1:nrows1
    if km1(z) == 1
        X = [c(1,:);ab1(kk,:)];
        dist = pdist(X,'euclidean');
        dis1 = dist + dis1;
        c1 = c1+1;
    end
    if km1(z) == 2
        X = [c(2,:);ab1(kk,:)];
        dist = pdist(X,'euclidean');
        dis2 = dist + dis2;
        c2=c2+1;
    end
    if km1(z) == 3
        X = [c(3,:);ab1(kk,:)];
        dist = pdist(X,'euclidean');
        dis3 = dist + dis3;
        c3=c3+1;
    end
    if km1(z) == 4
        X = [c(4,:);ab1(kk,:)];
        dist = pdist(X,'euclidean');
        dis4 = dist + dis4;
        c4=c4+1;
    end
    z = z+1;
end
%Similarities of 4 classes are used to find the better threshold value
sim1 = dis1/c1;
sim2 = dis2/c2;
sim3 = dis3/c3;
sim4 = dis4/c4;
%Mean of class similarities
mean1 = (sim1+sim2+sim3+sim4)/4;
sd1 = ((sim1-mean1).^2)+((sim2-mean1).^2)+((sim3-mean1).^2)+((sim4-mean1).^2);
sd1 = sd1/4;
%Standard deviation of class similarities
sd1 = sqrt(sd1);

%Calculating Threshold value using formula given in the paper.
l = mean1+(10*sd1); 

%Code for finding number of classes based on calculated threshold value
for go = 2:10
    [km, c] = kmeans(ab1,go);
    z = 1;
    flagger = 0;
    dist12 = 0.0;
    dist123 = 0.0;
    dist1 = 0.0;
    ccc = 0;
    sd1 = 0;
    for go1 = 1:go
        z=1;
        for kk =1:nrows1
            if km(z) == go1
                X = [c(go1,:);ab1(kk,:)];
                dist = pdist(X,'euclidean');
                dist1 = dist + dist1;
                ccc = ccc+1;
            end
            z = z + 1;
        end
        %Similarity of the Cluster
        alpha = dist1/ccc;
        %If cluster similarity is greater than threshold value, we divide
        %into more clusters else we break the loop to stop clustering.
        if alpha<l
            flagger = flagger+1;
        end
    end
    if flagger == go
        break;
    end       
end
% Each cluster segment is now displayed.
km = reshape(km,nrows,ncols);
for go2 = 1:go
    for i = 1:nrows
        for j = 1:ncols
            for k = 1:3
                if km(i,j)==go2
                    output(i,j,k)=he(i,j,k);
                else
                    output(i,j,k)=0;
                end
            end
        end
    end
    output1{go2}=output;
    output = im2uint8(output);
    figure
    imshow(output1{go2});
end
toc;